window.AppConfig = {
  host: 'superapp.seedao.tech',
  origin: 'https://superapp.seedao.tech',
};

