const signMsg = () =>{

}
export default {
  signMsg
}
