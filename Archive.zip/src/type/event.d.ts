export interface Ievent {
  cover_img: string;
  title: string;
  content: string;
  metadata: string;
  start_at: string;
  end_at: string;
}
