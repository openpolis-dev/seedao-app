export enum Wallet {
  METAMASK = 'METAMASK',
  UNIPASS = 'UNIPASS',
  JOYID = 'JOYID',
}

export enum WalletType {
  EOA = 'EOA',
  AA = 'AA',
}
